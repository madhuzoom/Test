package com.jpm.utils;

import com.jpm.model.EntityDetails;
import com.jpm.model.TradeType;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.Currency;
import java.util.HashSet;
import java.util.Set;

/**
 * 
 * @author Madhu
 *
 */
public class EntityDetailsBuilder {
	
    public static Set<EntityDetails> getEntityDetails() {
    	
        return new HashSet<>(Arrays.asList(

            new EntityDetails(  "foo",  
                TradeType.BUY,
                BigDecimal.valueOf(0.50),                
                Currency.getInstance("SGD"),
                LocalDate.of(2016, 1, 01),
                LocalDate.of(2016, 1, 02),
                200,
                BigDecimal.valueOf(100.25)),

            new EntityDetails(
                "bar",
                TradeType.SELL,
                BigDecimal.valueOf(0.22),                
                Currency.getInstance("AED"),
                LocalDate.of(2016, 1, 05),
                LocalDate.of(2016, 1, 07),
                450,
                BigDecimal.valueOf(150.5))

        ));
    }
}
