package com.jpm.bussinesslogic;

import com.jpm.model.EntityDetails;
import com.jpm.model.SGPWorkingDays;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

/**
 * 
 * @author Madhu
 *
 */
public class SettlementDateCalculator {

    public static Set<EntityDetails> calculateSettlementDates(Set<EntityDetails> entityDetails) {
    	
    	Map<String, Boolean> workingDaysMap = new HashMap<String, Boolean>();

    	
    	for(EntityDetails ed : entityDetails ){
    	
            if ( ed.getCurrency().getCurrencyCode().equals("AED") ) {
              	workingDaysMap = SGPWorkingDays.getSGPWorkingDays();
                } else  {
                  	workingDaysMap = SGPWorkingDays.getSGPWorkingDays();
                }
                	
            LocalDate newSettlementDate = findFirstWorkingDate(ed.getSettlementDate(), workingDaysMap);

            if (newSettlementDate != null) {
              	ed.setSettlementDate(newSettlementDate);
            }
    		
    	}
    	
    	return entityDetails;
    }

    
    private static LocalDate findFirstWorkingDate(LocalDate date, Map<String, Boolean> workingDaysMap) {

    	String dayOfWeek = date.getDayOfWeek().toString();
    
        if (workingDaysMap.get(dayOfWeek)) {
            return date;
        } else {
            return findFirstWorkingDate(date.plusDays(1), workingDaysMap);
        }
    }


}
