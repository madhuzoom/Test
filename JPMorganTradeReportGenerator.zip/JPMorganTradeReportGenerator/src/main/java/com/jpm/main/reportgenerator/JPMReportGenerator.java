package com.jpm.main.reportgenerator;

import com.jpm.bussinesslogic.SettlementDateCalculator;
import com.jpm.model.EntityDetails;
import com.jpm.model.TradeType;
import com.jpm.utils.EntityDetailsBuilder;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.function.Predicate;

public class JPMReportGenerator {

    public static void main(String[] args) {
    	
    	
        Set<EntityDetails> entityDetails = EntityDetailsBuilder.getEntityDetails();
        entityDetails = SettlementDateCalculator.calculateSettlementDates(entityDetails);
        System.out.println(displayReport(entityDetails));
        
    }
    
    private static String displayReport(Set<EntityDetails> entityDetails){
    	 StringBuilder sb = new StringBuilder();
    	Predicate<EntityDetails> buyingEntityDetailsPredicatet = entityDetails1 -> entityDetails1.getTradeType().equals(TradeType.BUY);
        Predicate<EntityDetails> sellingEntityDetailsPredicate =  entityDetails2 -> entityDetails2.getTradeType().equals(TradeType.SELL);
    	
        List<EntityDetails> buyingentityDetailsList = new ArrayList<>();
        List<EntityDetails> sellingentityDetailsList = new ArrayList<>();
        
        for(EntityDetails ed : entityDetails  ) {
        	if(buyingEntityDetailsPredicatet.test(ed)) {
        		buyingentityDetailsList.add(ed);
        	}

    	if(sellingEntityDetailsPredicate.test(ed)) {
    		sellingentityDetailsList.add(ed);
    	}
        
    	if(buyingentityDetailsList.size() == 1 && sellingentityDetailsList.size() == 1) {
    		// Rank as hard coded as1 because as part of buying we got only one entity
    		// Rank as hard coded as 1 because as part of selling we got only one entity    		
    		sb.append("---------buying entity details--------")
            .append("    Entity -->  foo, " +  "Rank ->  1,"  + " Date   -> " + buyingentityDetailsList.get(0).getSettlementDate() + ",Outgoing amount --> " + buyingentityDetailsList.get(0).getTradeAmount()  +"   \n")
            .append("---------selling entity details--------")
            .append("    Entity -->  bar, " +  "Rank ->  1,"  + " Date   -> " + sellingentityDetailsList.get(0).getSettlementDate() + ",Incoming amount --> " + sellingentityDetailsList.get(0).getTradeAmount()  +"   \n");
            
    	} else {
    		// we have to write a logic for ranking but we got only one entity as part of  buying and selling so I have not written logic here bacically I havnt get time to do this I am sorry. 
    	} 
    }
        return sb.toString();
 }
}