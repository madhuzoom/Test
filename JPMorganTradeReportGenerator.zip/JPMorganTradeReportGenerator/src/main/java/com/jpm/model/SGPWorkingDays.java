package com.jpm.model;

import java.util.HashMap;
import java.util.Map;

public enum SGPWorkingDays {
	
	SUNDAY("SUNDAY", false),
	MONDAY("MONDAY", true),
	TUESDAY("TUESDAY", true),
	WEDNESDAY("WEDNESDAY", true),
	THURSDAY("THURSDAY", true),
	FRIDAY("FRIDAY", true),
	SATURDAY("SATURDAY",false);

	
	
	String dayOfWeek;
	boolean isTradeAllowed;
	SGPWorkingDays(String dayOfWeek, boolean isTradeAllowed ){
		this.dayOfWeek = dayOfWeek;
		this.isTradeAllowed = isTradeAllowed;
	}
	
	public static Map<String, Boolean> getSGPWorkingDays (){
	
		Map<String, Boolean> sgpWorkingDaysMap = new HashMap<String, Boolean>();
		
		for( SGPWorkingDays sgpWorkingDays : SGPWorkingDays.values()){
					sgpWorkingDaysMap.put(sgpWorkingDays.dayOfWeek,sgpWorkingDays.isTradeAllowed);
		}
		
		return sgpWorkingDaysMap;
	}
	

}
