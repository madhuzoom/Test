package com.jpm.model;

import java.util.HashMap;
import java.util.Map;

public enum AEDWorkingDays {
	
	SUNDAY("SUNDAY", true),
	MONDAY("MONDAY", true),
	TUESDAY("TUESDAY", true),
	WEDNESDAY("WEDNESDAY", true),
	THURSDAY("THURSDAY", true),
	FRIDAY("FRIDAY", false),
	SATURDAY("SATURDAY",false);

	
	
	String dayOfWeek;
	boolean isTradeAllowed;
	AEDWorkingDays(String dayOfWeek, boolean isTradeAllowed ){
		this.dayOfWeek = dayOfWeek;
		this.isTradeAllowed = isTradeAllowed;
	}
	
	public static Map<String, Boolean> getAEDWorkingDays (){
	
		Map<String, Boolean> aedWorkingDaysMap = new HashMap<String, Boolean>();
		
		for( AEDWorkingDays aedWorkingDays : AEDWorkingDays.values()){
					aedWorkingDaysMap.put(aedWorkingDays.dayOfWeek,aedWorkingDays.isTradeAllowed);
		}
		
		return aedWorkingDaysMap;
	}
	

}
