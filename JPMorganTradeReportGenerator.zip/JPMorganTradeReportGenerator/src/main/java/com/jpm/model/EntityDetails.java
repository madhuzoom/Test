package com.jpm.model;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Currency;

/**
 * 
 * @author Madhu
 *
 */
public class EntityDetails {

    private  String entity;
    private TradeType tradeType;
    private BigDecimal agreedFx;
    private Currency currency;
    private LocalDate instructionDate;
    private LocalDate settlementDate;
    private int units;
    private BigDecimal pricePerUnit;    
    private BigDecimal tradeAmount;
    
    
    public EntityDetails( 
            String entity,
            TradeType  tradeType,
            BigDecimal agreedFx,
            Currency currency,
            LocalDate instructionDate,
            LocalDate settlementDate,
            int units,
            BigDecimal pricePerUnit)		    {
						    	
						    	this.entity = entity;
						        this. tradeType =  tradeType;
						        this.agreedFx = agreedFx;
						        this.currency = currency;;
						        this.instructionDate = instructionDate;
						        this.settlementDate = settlementDate;
						        this.units = units;
						        this.pricePerUnit = pricePerUnit;
						        this.tradeAmount = calculateAmount(pricePerUnit, units, agreedFx);
   }

    private static BigDecimal calculateAmount (
    										BigDecimal pricePerUnit, 
    										int units,
    										BigDecimal agreedFx  ) {
        									return pricePerUnit.multiply(BigDecimal.valueOf(units)).multiply(agreedFx);
    }
    
    


    public String getEntity() {
		return entity;
	}

	public void setEntity(String entity) {
		this.entity = entity;
	}

	public TradeType getTradeType() {
		return tradeType;
	}

	public void setTradeType(TradeType tradeType) {
		this.tradeType = tradeType;
	}

	public BigDecimal getAgreedFx() {
		return agreedFx;
	}

	public void setAgreedFx(BigDecimal agreedFx) {
		this.agreedFx = agreedFx;
	}

	public Currency getCurrency() {
		return currency;
	}

	public void setCurrency(Currency currency) {
		this.currency = currency;
	}

	public LocalDate getInstructionDate() {
		return instructionDate;
	}

	public void setInstructionDate(LocalDate instructionDate) {
		this.instructionDate = instructionDate;
	}

	public LocalDate getSettlementDate() {
		return settlementDate;
	}

	public void setSettlementDate(LocalDate settlementDate) {
		this.settlementDate = settlementDate;
	}

	public int getUnits() {
		return units;
	}

	public void setUnits(int units) {
		this.units = units;
	}

	public BigDecimal getPricePerUnit() {
		return pricePerUnit;
	}

	public void setPricePerUnit(BigDecimal pricePerUnit) {
		this.pricePerUnit = pricePerUnit;
	}

	public BigDecimal getTradeAmount() {
		return tradeAmount;
	}

	public void setTradeAmount(BigDecimal tradeAmount) {
		this.tradeAmount = tradeAmount;
	}

	@Override
    public String toString() {
        return entity;
    }
}
